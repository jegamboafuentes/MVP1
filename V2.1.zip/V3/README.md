# MVP1
 MVP1 of Metaverse Professional Browser Extensions
